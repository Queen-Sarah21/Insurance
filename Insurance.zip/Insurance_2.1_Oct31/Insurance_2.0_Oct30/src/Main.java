
import Factory.Factory;
import Insurance.User;
import Insurance.InsuranceAgreement;


import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Random;
import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        ManagerSoftware managerSoftware = new ManagerSoftware();

        managerSoftware.run();

    }
}
